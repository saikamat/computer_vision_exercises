house = godthem256;
curves = edgecurves(house, 4, 3.5, 'same');
overlaycurves(house, curves);

tools = few256;
curves = edgecurves(tools, 4, 8, 'same');
overlaycurves(tools, curves);
